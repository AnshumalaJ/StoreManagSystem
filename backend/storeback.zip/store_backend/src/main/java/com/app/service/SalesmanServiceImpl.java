package com.app.service;

public class SalesmanServiceImpl implements ISalesmanService {

}
