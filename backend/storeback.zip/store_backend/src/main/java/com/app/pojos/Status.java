package com.app.pojos;

public enum Status {
   DELIVERED,NOTDELIVERED;
}
