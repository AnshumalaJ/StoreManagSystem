package com.app.service;

public interface ISalesmanService {

}
