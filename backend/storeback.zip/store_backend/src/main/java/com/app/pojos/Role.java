package com.app.pojos;

public enum Role {
	ADMIN, SALESMAN, SUPPLIER;
}
