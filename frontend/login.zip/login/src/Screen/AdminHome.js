import React,{ useEffect,useState} from "react";
import { Link,useHistory } from 'react-router-dom';

export default function Adminhome(){
    return(
        <>
        <h3> Hello admin</h3>
        </>
    )
}